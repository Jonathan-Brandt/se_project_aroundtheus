# Project 3: Around The U.S.

### Overview

- Project Name
- Figma
- Images

**Project Name**

Project 3, Around the U.S

**Project Description**

This is the 3rd completed project I have done at TripleTen as a part of my academic journey to becoming a software enjineer.

**Plans for improvement**

I will be working with this project further as a template for sprint 4 project 4.

**Github pages link**

https://crustaceanjames.github.io/se_project_aroundtheus/

**Video Tour**

https://screenrec.com/share/0Xh8yFAJO3
